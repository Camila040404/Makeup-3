function mensaje() {
  alert("💖 Gracias por contactar Makeup 💄✨");
}